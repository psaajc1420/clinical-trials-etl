version_info = (22, 1, 0, "")
__version__ = '.'.join([str(part) for part in version_info if part or part == 0])
