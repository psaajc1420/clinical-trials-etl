
from glom.cli import console_main

if __name__ == '__main__':
    console_main()
