from .index import attrs_plugin  # noqa: F401
