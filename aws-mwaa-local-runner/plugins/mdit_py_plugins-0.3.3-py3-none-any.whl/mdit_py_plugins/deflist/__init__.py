from .index import deflist_plugin  # noqa F401
