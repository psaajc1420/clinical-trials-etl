from cattrs.disambiguators import create_uniq_field_dis_func

__all__ = ["create_uniq_field_dis_func"]
